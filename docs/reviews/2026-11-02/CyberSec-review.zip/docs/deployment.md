> Current repository baseline: [CYBERSEC_BASELINE.md](CYBERSEC_BASELINE.md). Use Python 3.12.16, Node 22.23.4 and hash-verified Python installs. Configure separate restricted-runtime `DATABASE_URL` and schema-owner `MIGRATION_DATABASE_URL` secrets, then use `sh start-hosted.sh` as the Render start command. The wrapper removes the migration credential before starting the API. Provision and verify both roles/grants with the database administrator before deploying. The Compose PostgreSQL 18.6 baseline does not upgrade a managed Supabase/Render database; confirm its live version and extensions with the provider.

# Deploying WellCostIQ: Vercel + Render + Supabase

This guide deploys the three parts of the application to three managed services:

```
Browser ──HTTPS──▶ Vercel   (React SPA, static files)
                     │  /api/*  (rewrite proxies — same-origin from the browser)
                     ▼
                  Render   (FastAPI + uvicorn, Python web service)
                     │  DATABASE_URL
                     ▼
                  Supabase (PostgreSQL)
```

**Why this split works without code changes:** the frontend calls the API with
relative URLs (`/api/v1/...`), and the refresh token is an HttpOnly cookie scoped
to `/api/v1/auth`. Vercel's `rewrites` (see `frontend/vercel.json`) proxy those
paths to Render, so from the browser's perspective everything is same-origin and
the cookie keeps working. No `VITE_*` build-time variables are required.

Estimated setup time: 30–60 minutes, excluding time spent troubleshooting provider-specific errors.

> **Before retrying a failed deployment:** do not create duplicate Render services or Supabase projects. Inspect the existing Render service's **Events** and **Logs**, confirm the configuration below, and redeploy the existing service. Never paste database URLs, secrets, or administrator passwords into support chats or issue reports.

### Verified repository deployment contract

- Render must run from `backend/`; it contains `requirements.txt`, `alembic.ini`, `alembic/`, and `app/`.
- Vercel must build from `frontend/`; its frontend calls relative `/api/v1` URLs and requires no `VITE_API_URL`.
- `frontend/vercel.json` must contain the actual Render hostname. If the Render
  service is renamed, update every external rewrite and redeploy Vercel.
- `GET /api/health` is a **liveness** check that returns only `{"status":"ok","api_version":"..."}`. It deliberately does not disclose whether an administrator exists, and it is not a database-readiness check. Confirm first-run setup from the Render logs (`Seeded administrator ...`) and by signing in.
- The migration head is **`b7c1d9e4f2a8`** (password expiry and refresh-token replay detection). Render's start command must run `alembic upgrade head` before Uvicorn.
- The browser sends an `Origin` header through the Vercel rewrite, so `CORS_ORIGINS` must list the exact Vercel origin (or custom domain) even though the browser sees a same-origin URL.
- Render's current default Python runtime may differ from the one used during development. **Pin Python 3.12** as shown below rather than relying on Render's default.

---

## 1. Supabase — PostgreSQL database

Supabase's [Postgres connection guide](https://supabase.com/docs/guides/database/connecting-to-postgres)
explains the available connection modes; choose **Session pooler** for this
long-running Render API.

1. Sign up at [Supabase](https://supabase.com) and create a **New project**.
   Choose a strong database password and a region close to Render (and your
   users). Save the database password in a password manager; it is not your
   Supabase account password.
2. Wait for the database to finish provisioning. Supabase creates the database;
   the first Render deploy runs this application's Alembic migrations to create
   its tables.
3. In the Supabase project, click **Connect** and select **Session pooler**.
   Copy its URI. Use the session pooler for Render: it is reachable over IPv4
   and supports persistent backend connections. Do not use the **Transaction
   pooler** for this SQLAlchemy application.
4. Convert the copied URI to the SQLAlchemy/psycopg form Render needs:

   ```text
   postgresql+psycopg://<POOLER_USER>:<URL_ENCODED_PASSWORD>@<POOLER_HOST>:5432/postgres?sslmode=require
   ```

   Keep the actual username, host, port, and database name from Supabase's
   copied Session pooler URI. Usually its username includes the project ref
   (for example, `postgres.<PROJECT_REF>`); do not replace it with `postgres`
   unless Supabase shows that exact username. Change only the URI scheme from
   `postgresql://` to `postgresql+psycopg://`, and add `?sslmode=require` (or
   `&sslmode=require` if the URI already has query parameters).

   URL-encode reserved characters in the database password (`@`, `#`, `%`, `/`,
   `?`, `&`, spaces, etc.). For example, `@` becomes `%40`. Do not include the
   angle brackets or placeholder text in the final value.

   A **Direct connection** is also valid if the Render service can reach the
   Supabase direct endpoint (typically IPv6, or IPv4 with Supabase's IPv4
   add-on). The Session pooler is the simpler choice when direct connections
   fail with DNS, IPv6, or network errors. The Transaction pooler (usually
   port `6543`) is intended for short-lived/serverless connections and is not
   the fallback recommended here.

Before using either connection, ask the database administrator to provision the
separate roles and grants in [the current baseline](CYBERSEC_BASELINE.md).
Supabase's default `postgres.<PROJECT_REF>` administrator URI is for database
administration; do not put it in the API runtime configuration. Obtain the
provider-correct pooler username/URI for each dedicated role rather than guessing
from the administrator URI.

**Supabase notes**

- Check Supabase's current plan limits and pause policy in the dashboard; the
  database must be available when the API starts and handles requests.
- The app enforces tenant isolation in the API layer, not via Row Level
  Security. Only the Render service should know `DATABASE_URL` — never expose it
  to the browser (this deployment keeps it server-side only).
- Optional hardening: **Project Settings → Database → Network Restrictions** to
  allow only Render's outbound IPs (paid Render plans have static IPs; free-tier
  IPs are dynamic, so skip this on the free plan).

---

## 2. Render — FastAPI backend

These settings follow Render's [web service deployment
guide](https://render.com/docs/web-services).

The dashboard method below is the easiest way to get a first deploy working.
The repository's Blueprint is an alternative if you want Render to create the
service from `render.yaml`.

### Option A: Create the service in the dashboard

1. Push the application code to GitHub and make sure the branch you want to
   deploy contains `backend/requirements.txt`, `backend/alembic.ini`,
   `backend/alembic/`, and `backend/app/`.
2. Sign in at [Render](https://render.com). Choose **New → Web Service**, connect
   GitHub if asked, and select the `praveen-christuraj/WellCostingPro`
   repository. Select the branch you intend to deploy (commonly `main`).
3. Set these fields in the service form. The root directory is important: it
   makes all commands run from `backend/`.

   | Setting | Value |
   |---|---|
   | Name | `wellcosting-api` (or another available name; copy the actual URL Render assigns) |
   | Region | Same region as the Supabase project, or the nearest available region |
   | Environment | **Python 3** |
   | Python version | Set environment variable `PYTHON_VERSION=3.12.16` (pin for first deploy) |
   | Root Directory | `backend` |
   | Build Command | `pip install --require-hashes -r requirements.txt` |
   | Start Command (Free plan) | `sh start-hosted.sh` |
   | Health Check Path | `/api/health` |
   | Instance plan | Free for testing (sleeps when idle); choose a paid instance for an always-on service |

   Render provides `PORT`; the startup wrapper binds Uvicorn to that port.
   The wrapper runs migrations using `MIGRATION_DATABASE_URL`, removes that
   variable, and starts the API with the restricted `DATABASE_URL`. This works
   on both Free and paid plans. Do not also configure a duplicate migration
   command. A separate paid pre-deploy job is another option only when it has
   its own migration secret and the API job does not receive that secret.
4. In the service form's **Advanced** section, set `PYTHON_VERSION=3.12.16` and add the environment variables
   from the next section before creating the service. In particular, set the
   `DATABASE_URL` and `MIGRATION_DATABASE_URL` for the two dedicated roles, a `SECRET_KEY`, and `CORS_ORIGINS` to the production
   Vercel origin you plan to use. If you have not created the Vercel project
   yet, use the expected `https://<project>.vercel.app` origin and correct it
   after the first Vercel deployment.
5. Click **Create Web Service**. Watch **Events** and **Logs** in the Render
   dashboard until the deploy is live. Record the actual `https://...onrender.com`
   URL shown for the service; the service name may not be available as typed.

### Option B: Create it from the Blueprint

1. Push the latest repository changes to GitHub. In Render choose **New →
   Blueprint**, connect this repository and branch, and confirm that Render
   found `render.yaml` in the repository root.
2. Review the proposed `wellcosting-api` service and click **Deploy Blueprint**.
   The Blueprint uses the Free-compatible migration/start command described
   above.
3. During initial Blueprint creation, enter the `sync: false` values when
   prompted. For `CORS_ORIGINS`, use the expected production Vercel origin and
   correct it after Vercel's first deployment if needed. Render prompts only on
   the first Blueprint creation; for later changes, edit the service's
   **Environment** page directly.
4. Follow the deploy in the service's Events and Logs. If you already created a
   separate dashboard-managed Render service, do not apply the Blueprint too:
   choose one management method to avoid creating a duplicate service.

### Environment variables for the API

| Variable | Required | Value / how to generate |
|---|---|---|
| `PYTHON_VERSION` | **Yes for reproducible first deploy** | `3.12.16` (pin a supported Python 3.12 patch release; Render currently defaults new services to Python 3.14) |
| `DATABASE_URL` | **Yes** | Restricted application-role Session pooler URI, `postgresql+psycopg://`, `sslmode=require`; never the cluster administrator |
| `MIGRATION_DATABASE_URL` | **Yes** | Distinct schema-owner migration-role URI for `start-hosted.sh`; removed before the API starts |
| `SECRET_KEY` | **Yes** | Generate a unique key with `openssl rand -hex 32`; on Windows PowerShell, `py -c "import secrets; print(secrets.token_hex(32))"` also works. Use at least 32 characters per environment; the app rejects a missing, short, or default key with PostgreSQL. |
| `SECURE_COOKIES` | **Yes** | `true` — Vercel serves HTTPS, and the refresh cookie is set with the `Secure` flag |
| `CORS_ORIGINS` | **Yes** | Exact Vercel origin(s), comma-separated, e.g. `https://wellcostiq.vercel.app`. Add custom domains too. No paths or trailing slash. |
| `BOOTSTRAP_ADMIN_ON_STARTUP` | No | `true` (default). Set `false` only if you seed manually. |
| `SEED_ORG_SLUG` | First boot | Workspace ID, e.g. `my-company` |
| `SEED_ORG_NAME` | First boot | Display name, e.g. `My Company` |
| `SEED_OWNER_NAME` | First boot | Administrator's name, e.g. `Jane Smith` |
| `SEED_ADMIN_EMAIL` | First boot | Administrator e-mail, e.g. `owner@example.com` |
| `SEED_ADMIN_PASSWORD` | First boot | Password, **12+ characters**. **Delete this variable only after logs confirm seeding and a login succeeds** (see §4). |
| `ACCESS_TOKEN_MINUTES` | No | Default `15` |
| `REFRESH_TOKEN_DAYS` | No | Default `7` |
| `APP_NAME` | No | Default `WellCostIQ` |
| `APP_TAGLINE` | No | Default `Well Cost Estimation & Tracking`; shown as the API description in `/docs` and OpenAPI |

Notes:

- Never commit these to Git. Render's dashboard/blueprint stores them encrypted;
  the repo's `.gitignore` already excludes `.env`.
- **Free-tier cold starts:** Render spins down a Free web service after 15
  minutes without inbound traffic; waking it can take about a minute. The API
  filesystem is ephemeral, so keep the database on Supabase, not local SQLite.
- Verify the deploy at `https://<actual-service-url>.onrender.com/api/health`.
  It should return `{"status":"ok","api_version":"..."}`. This is a liveness
  check only: it is **not** proof of database connectivity and it no longer
  discloses setup state. Confirm the database and the first administrator from
  the Render logs and by signing in once.
- Verify migrations in the Render deploy/runtime logs: they should complete
  before Uvicorn starts. If the log says `alembic: command not found`, check
  that `pip install --require-hashes -r requirements.txt` succeeded and that the root directory
  is exactly `backend`.

---

## 3. Vercel — React frontend

1. Sign up at [Vercel](https://vercel.com), choose **Add New → Project**, and
   import the `praveen-christuraj/WellCostingPro` repository. Select the same
   production branch you selected for Render.
2. Configure the project:

   | Setting | Value |
   |---|---|
   | Framework Preset | **Vite** |
   | Root Directory | `frontend` |
   | Build Command | `npm run build` (default) |
   | Output Directory | `dist` (default) |
   | Install Command | `npm ci` (enforced by `frontend/vercel.json`) |
   | Node.js version | Select **22.x**; verify the deployed patch is at least 22.23.4, as required by `package.json` |
   | Production Branch | The branch you deploy (commonly `main`) |

3. **Environment variables: none are required.** The frontend has no build-time
   configuration — it calls the API with relative `/api` paths.
4. **Point Vercel's proxy at the live Render service.** Edit
   `frontend/vercel.json` in the repository. Replace every
   `YOUR-RENDER-SERVICE.onrender.com` with the actual Render hostname from §2
   (hostname only, no trailing slash), for example:

   ```json
   {
     "rewrites": [
       { "source": "/api/:path*", "destination": "https://wellcosting-api.onrender.com/api/:path*" },
       { "source": "/((?!api/).*)", "destination": "/index.html" }
     ]
   }
   ```

   Keep the single `/api/...` backend rewrite before the SPA fallback. Do **not**
   add `/docs`, `/redoc` or `/openapi.json` rewrites: production disables the
   API documentation, and the repository's `vercel.json` refuses those paths.
   The fallback lets React Router serve direct visits and browser refreshes such
   as `/login`; without it Vercel returns 404 for client-side routes. Vercel reads
   this file from the project root directory (`frontend/`). See
   [Vercel project configuration](https://vercel.com/docs/project-configuration)
   for details about `vercel.json`.
5. Commit and push this `vercel.json` change to the production branch. Vercel
   auto-deploys when that branch receives a push. A deployment made before this
   change will still contain the previous proxy/fallback configuration.
6. In Vercel, open the project's **Deployments** page and wait for the latest
   deployment to finish. Open the assigned production domain (not a preview
   deployment URL) and record its origin, e.g.
   `https://wellcostiq.vercel.app`.
7. Return to Render → service → **Environment**. Set `CORS_ORIGINS` to that
   exact origin (scheme + hostname, with no path/trailing slash); include any
   custom domain as another comma-separated origin. Save and redeploy. No
   `VITE_*` variables are needed in Vercel.
8. Open `https://<your-vercel-domain>/api/health`. It should return
   `{"status":"ok","api_version":"..."}` through Vercel's rewrite. Confirm that
   `https://<your-vercel-domain>/docs` returns **404** — that is the intended
   production behaviour, not a fault.

**Custom domain (optional):** *Project → Settings → Domains*, add and verify
your domain. Add its exact HTTPS origin to Render's `CORS_ORIGINS` (comma
separated) and redeploy the API. The `vercel.json` rewrite still targets the
Render service; do not point the browser directly at Render.

---

## 4. First-run administrator (seeding)

A fresh database has no users, so nobody can sign in. Pick one option:

**Option A — `SEED_*` environment variables in Render (recommended for a first
deploy, including Free):** before the first API start, set all five variables:
`SEED_ORG_SLUG`, `SEED_ORG_NAME`, `SEED_OWNER_NAME`, `SEED_ADMIN_EMAIL` and
`SEED_ADMIN_PASSWORD` (§2). Use a workspace slug such as `my-company`, a valid
owner email, and a unique password of at least 12 characters. The API applies
Alembic migrations first, then creates the initial workspace and owner from
these values. Wait for Render logs to report `Seeded administrator ...`, then
**sign in once successfully**. Only then **remove `SEED_ADMIN_PASSWORD`** from
Render's Environment page and redeploy. Removing the other four seed values is
also recommended. The health endpoint intentionally does not report setup state,
so the log line and a successful sign-in are the evidence.

**Option B — from your computer against Supabase:** use the same Session pooler
`DATABASE_URL` as Render and run the seeding CLI from `backend/`. This requires
Python dependencies installed locally and network access to Supabase. The CLI
asks for the workspace, administrator and password. Do not commit connection
strings or passwords to Git. `python -m app.seed --check` reports status
without changing anything (`0` = administrator present).

**Option C — Render Shell:** if your Render plan provides a Shell, open it for
the API service and run `python -m app.seed`. Shell availability depends on the
service plan; use Option A or B if the Shell tab is unavailable.

Then sign in at your Vercel URL with the **workspace slug**, the administrator
e-mail and the password you chose.

---

## 5. Post-deploy checklist

- [ ] `SECRET_KEY` is a unique random value (≥32 chars), never committed.
- [ ] `SECURE_COOKIES=true` on Render; the app is HTTPS-only end to end.
- [ ] `CORS_ORIGINS` lists the exact Vercel origin(s) — no `*`, since cookies are allowed.
- [ ] `SEED_ADMIN_PASSWORD` deleted from Render after the first boot.
- [ ] Sign-in works and the Overview page loads data through the proxy.
- [ ] `GET /api/health` through both Render and Vercel returns
      `{"status":"ok","api_version":"..."}` and nothing else.
- [ ] `GET /docs`, `/redoc` and `/openapi.json` return 404 in production.
- [ ] `PASSWORD_MAX_AGE_DAYS=90`, `PASSWORD_HISTORY_LIMIT=5`, `MAX_FAILED_LOGINS=5`,
      `LOCKOUT_MINUTES=15` are set (or the documented defaults are accepted), and
      `TRUSTED_PROXY_IPS` is empty on Render because the API is directly reachable.
- [ ] Auto-deploy is enabled on both Render and Vercel for the selected production branch.
- [ ] Consider a paid Render instance to avoid idle spin-down and review
      Supabase plan limits, network restrictions, and custom-domain needs.

## 6. Troubleshooting

### Diagnostic sequence: follow this order instead of guessing

1. **Build failed:** open Render → service → **Events → failed deploy → Logs**. Check Python version, `backend` root directory, and dependency installation. Set `PYTHON_VERSION=3.12.16` and use **Save, rebuild, and deploy** if changing the runtime.
2. **Build succeeded but startup failed:** locate the first error after `alembic upgrade head`. If it says `password authentication failed`, `could not translate host name`, or `connection refused`, fix the Supabase Session pooler URI. If it says `SECRET_KEY`, fix that variable. If it says `alembic` or `ModuleNotFoundError`, verify the root directory and installed requirements.
3. **Service live but sign-in is impossible:** inspect the Render logs for `Administrator setup failed`, `No administrator account exists`, migration errors or database exceptions. Verify that all five `SEED_*` variables are set and that migrations finished. `/api/health` no longer reports setup state, and HTTP 200 from it is not proof of a working database.
4. **Render API works, Vercel API fails:** check `frontend/vercel.json` for the actual Render hostname, commit the change, and verify a new production Vercel deployment. Test `https://YOUR-VERCEL-DOMAIN/api/health` before testing login.
5. **Login fails:** confirm from the Render logs that the administrator was seeded, then use the exact workspace slug, email and password configured in Render. Remember that a password older than `PASSWORD_MAX_AGE_DAYS` must be changed at sign-in, and a wrong password five times locks the account for `LOCKOUT_MINUTES`. Check Render logs for validation errors. Never reset the database simply to fix login.

`ERR_HTTP2_PROTOCOL_ERROR` on both `/api/health` and `/api/v1/auth/login` is
normally an upstream availability failure, not invalid login credentials. Test
the Render health URL directly first. If it is unavailable, inspect the first
Render startup error after `alembic upgrade head`; if it works directly but not
through Vercel, verify the external rewrite hostname and redeploy Vercel.

### Safe database URL validation

In Supabase → **Connect → Session pooler**, copy the URI **as a whole**. Preserve its host and username (commonly `postgres.PROJECT_REF`), port `5432`, and database name. Replace the URI prefix with `postgresql+psycopg://`, insert the database password with reserved characters percent-encoded, and append `sslmode=require` using `?` or `&` as appropriate. Do not mix the direct-connection username/host with the pooler hostname. Do not send the completed URI to anyone.

### First-deployment pass/fail gates

- **Gate A:** Render build installs Python dependencies without errors.
- **Gate B:** Alembic migrations finish, followed by Uvicorn listening on Render's `PORT`.
- **Gate C:** Render logs confirm administrator provisioning (`Seeded administrator ...`).
- **Gate D:** Vercel `/api/health` reaches Render via the rewrite.
- **Gate E:** Login works at the Vercel production domain; only now remove the bootstrap password.


| Symptom | Likely cause |
|---|---|
| Render build says `requirements.txt` is missing | Set Render Root Directory to `backend` (commands are relative to it) |
| API routes return Vercel 404/405 or do not reach Render | Replace the `YOUR-RENDER-SERVICE` placeholder in `frontend/vercel.json`, commit, push, and wait for a fresh Vercel deploy |
| Login page shows a seeding hint | No admin has been provisioned yet; check the Render logs and complete §4 |
| Sign-in is refused and no owner exists | Inspect Render logs for the seeding step and confirm migrations/database connectivity; `/api/health` intentionally does not report setup state |
| Render logs show `could not translate host name`, timeout, or IPv6/network errors | Use the Supabase Session pooler URI (host/user/port copied from **Connect → Session pooler**) rather than the Direct endpoint; do not use Transaction pooler |
| Render logs show `password authentication failed for user "postgres"` on port `6543` | Render is using the Transaction pooler endpoint and/or a username that does not match the copied pooler URI. In Supabase **Connect → Session pooler**, copy the full connection URI; preserve its generated username (usually `postgres.<PROJECT_REF>`), host, and port `5432`. In Render → service → **Environment**, replace `DATABASE_URL` with that URI using the `postgresql+psycopg://` scheme and `sslmode=require`. URL-encode reserved password characters, save with **Save, rebuild, and deploy**, then inspect the new logs. Do not merely change `6543` to `5432` while keeping the old username or guessed host. |
| Render logs show password authentication failed with another user/port | Re-copy the full connection URI from Supabase **Connect** and use its matching host, port, and username. Confirm the database password is current and reserved characters are URL-encoded. Update `DATABASE_URL` in Render's Environment page and redeploy. |
| Render logs show missing tables / Alembic revision errors | Confirm the start command runs `alembic upgrade head` before Uvicorn, or on a paid instance configure it as Pre-Deploy Command; verify the Render root directory is `backend` |
| Browser reports a CORS error | `CORS_ORIGINS` must contain the exact Vercel origin (scheme + host, no trailing slash); save and redeploy Render |
| Login succeeds but the next call is 401 | `SECURE_COOKIES` mismatch, or the cookie was set on the wrong domain — confirm you're browsing the Vercel URL, not calling Render directly |
| Render deploy fails: `SECRET_KEY` error | Missing/short/default `SECRET_KEY` when using PostgreSQL |
| First load very slow | The Free Render service may be waking from idle; this is expected for that plan |

## 7. Alternative: calling the API cross-origin (not recommended)

The frontend could instead call Render directly (`VITE_API_URL=https://...onrender.com`)
with the API's CORS enabled. That requires a small code change in
`frontend/src/lib/api.ts` (read `import.meta.env.VITE_API_URL` as the base URL) and
`credentials: 'include'` across origins. The rewrite approach above avoids code
changes and keeps the refresh cookie same-origin, so it is the recommended path.
